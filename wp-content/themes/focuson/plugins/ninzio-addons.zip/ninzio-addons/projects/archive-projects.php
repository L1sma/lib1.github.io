<?php

	get_header();
		include(NINZIO_ADDONS.'projects/content-projects-header.php');
		include(NINZIO_ADDONS.'projects/content-projects-body.php');
	get_footer(); 

?>